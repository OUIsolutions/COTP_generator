

int cotp_minutes(int minutes);
int copt_hours(int hours);
int cotp_days(int days);